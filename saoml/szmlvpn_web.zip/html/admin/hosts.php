<?php
	include('head.php');
	include('dns.php');
	function unsetLine($arr){
	foreach($arr as $v){
		if(strpos($v,"apache") === 0){
			
		}else{
			$line[] = $v;
		}
	}
	return $line;
}
	$m = new Map();
 	if($_GET['act'] == 'update'){
		

		$info = file_put_contents("/etc/saoml_hosts",$_POST["content"]);
 		
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
		
	}else{
		$action = "?act=update";
		
		$info = file_get_contents("/etc/saoml_hosts");
		//$p = '/default\s([0-9]*)/';
	//preg_match($p,$info,$m);
		
 ?>
<div class="main">
	<div class="box">
		<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>">
			<span class="label label-default">自定义DNS</span>
		<h3>自定义DNS列表</h3>
			示例:127.0.0.1 www.baidu.com 则用户访问百度会被屏蔽
			请等页面加载完毕再操作，否则卡死你个瓜娃子，导入后点立即拦截
		<hr>
				<button type="submit" class="btn btn-app-red">一键导入</button>

			<textarea class="form-control" rows="20" name="content"><?php echo $info ?></textarea>
			<br>
	</form> 
	</div>
</div>
<script>
function cmds(line){
	if(confirm("立即使HOST表生效？")){
		$.post('fas_service.php',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("执行完毕");
				 location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
        <!-- End Apps Modal -->

        <div class="app-ui-mask-modal"></div>

        <!-- AppUI Core JS: jQuery, Bootstrap, slimScroll, scrollLock and App.js -->
        <script src="assets/js/core/jquery.min.js"></script>
        <script src="assets/js/core/bootstrap.min.js"></script>
        <script src="assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="assets/js/core/jquery.placeholder.min.js"></script>
        <script src="assets/js/app.js"></script>
        <script src="assets/js/app-custom.js"></script>

        <!-- Page Plugins -->
        <script src="assets/js/plugins/slick/slick.min.js"></script>
        <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

        <!-- Page JS Code -->
        <script src="assets/js/pages/index.js"></script>
        <script>
            $(function()
            {
                // Init page helpers (Slick Slider plugin)
                App.initHelpers('slick');
            });
        </script>
<?php
	}
	include('footer.php');
?>
