<?php
include('head.php');
include('tc.php');
?><style>
.row-col{
		background:#fff;
		border:1px solid #ccc;
		border-top:1px solid #ddd;
		border-left:1px solid #ddd;
		padding:15px;
	}
.sub{
	font-size:16px;
}
	.row-col h3{
		color:#777;
	}
	.row-col p{
		padding:15px;
	}</style>
<?php 	
 	if($_GET['act'] == 'del'){
		$db = db('app_tc');
		if($db->where(array('id'=>$_POST['id']))->delete()){
			db("app_kms")->where(array('type_id'=>$_POST['id']))->delete();
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}elseif($_GET['act'] == 'show'){
		$show = $_POST['show'] == '1' ? "1" : "0";
		$db = db('app_tc');
		if($db->where(array('id'=>$_POST['id']))->update(array('show'=>$show))){
			die(json_encode(array("status"=>'success')));
		}else{
			die(json_encode(array("status"=>'error')));
		}
		
	}else{
 ?>
                <main class="app-content">
                    <!-- Page Content -->
                    <div class="container-fluid p-y-md">
                        <!-- Modern Design -->
                        <div class="row">
	<?php 
		$db = db('app_tc');
		$list = $db->where(array())->order('id DESC')->select();
		foreach($list as $vo){
		echo '<div class="col-sm-6 col-lg-3">';
		echo '<a class="card hover-shadow-3 text-center" href="javascript:void(0)">';
		echo '<div class="card-header">';
		echo '<h4 class="h3">套餐</h4>';
		echo '</div>';
		echo '<div class="card-block bg-green bg-inverse">';
		echo '<div class="h1 m-y-sm">'.$vo['name'].'</div>';
        echo '<div class="h5 font-300 text-muted m-t-0">日期</div>';
        echo '</div>';
        echo '<div class="card-block">';
        echo '<table class="table table-borderless table-condensed">';
        echo '<tbody>';
        echo '<tr>';
        echo '<td><strong>价格：'.$vo["jg"].'元</strong></td>';
		echo '</tr>';
        echo '<tr>';
        echo '<td><strong>流量：'.$vo["rate"].'M</strong></td>';
        echo '</tr>';
        echo '<tr>';
        echo '<td><strong>期限：'.$vo["limit"].'天</strong></td>';
        echo '</tr>';
        echo '</tbody>';
		echo '<a type="button" class="btn btn-app" href="km_list.php?tid='.$vo['id'].'">管理</a>&nbsp;';
		echo '<button type="button" class="btn btn-app" onclick="window.location.href=\'add_tc.php?act=mod&id='.$vo['id'].'\'">编辑</button>&nbsp;';
		echo '<button type="button" class="btn btn-app" onclick="delLine(\''.$vo['id'].'\')">删除</button>&nbsp;';

        echo '</table>';
		echo '</div>';
		echo '</a>';
		echo '</div>';
		}
	?>
			<!-- echo '<a class="btn btn-app" href="'.$vo["url"].'" target="_blank">购买</a>'; -->
	</div>
	</div>
	</main>
<?php
	}
	include('footer.php');
	
?>
<script>
function qiyong(id){
	var doc = $('.line-id-'+id+' .showstatus');
	if(doc.attr('data') == "1"){
		doc.html("已禁用").attr({'data':'0'});
	}else{
		doc.html("已启用").attr({'data':'1'});
	}
	var url = "list_tc.php?act=show";
		var data = {
			"id":id,
			"show":doc.attr('data')
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("操作失败");
			}
		},"JSON");
}
function delLine(id){
	if(confirm('确认删除吗？删除后不可恢复哦！')){
		$('.line-id-'+id).slideUp();
		var url = "list_tc.php?act=del";
		var data = {
			"id":id
		};
		$.post(url,data,function(data){
			if(data.status == "success"){

			}else{
				alert("删除失败");
			}
		},"JSON");
	}
}
</script>
 <script src="assets/js/core/jquery.min.js"></script>
        <script src="assets/js/core/bootstrap.min.js"></script>
        <script src="assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="assets/js/core/jquery.placeholder.min.js"></script>
        <script src="assets/js/app.js"></script>
        <script src="assets/js/app-custom.js"></script>

        <!-- Page Plugins -->
        <script src="assets/js/plugins/slick/slick.min.js"></script>
        <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

        <!-- Page JS Code -->
        <script src="assets/js/pages/index.js"></script>
        <script>
            $(function()
            {
                // Init page helpers (Slick Slider plugin)
                App.initHelpers('slick');
            });
        </script>
