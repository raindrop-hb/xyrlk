<?php
//加密方式：php源码混淆类加密。免费版地址:https://www.zhaoyuanma.com/phpjm.html 免费版不能解密,可以使用VIP版本。
//此程序由【找源码】http://Www.ZhaoYuanMa.Com (免费版）在线逆向还原，QQ：7530782 
?>
<?php
$numrows = db(_openvpn_)->where(_iuser_." LIKE :kw",[":kw"=>"%".$_GET["kw"]."%"])->getnums();
$nums2 = db(_openvpn_)->where(["online"=>"1"])->getnums();
?>
<!DOCTYPE html>

<html class="app-ui">

   <head>
       <!-- Meta -->
       <meta charset="UTF-8" />
       <meta http-equiv="X-UA-Compatible" content="IE=edge" />
       <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />

       <!-- Document title -->
       <title>SaoML后台管理</title>

       <meta name="description" content="AppUI - Admin Dashboard Template & UI Framework" />
       <meta name="author" content="rustheme" />
       <meta name="robots" content="noindex, nofollow" />

       <!-- Favicons -->
       <link rel="apple-touch-icon" href="assets/img/favicons/apple-touch-icon.png" />
       <link rel="icon" href="assets/img/favicons/favicon.ico" />

       <!-- Google fonts -->
       <link rel="stylesheet" /><!--href="http://fonts.googleapis.com/css?family=Roboto:300,400,400italic,500,900|Roboto+Slab:300,400|Roboto+Mono:400"--> 

       <!-- Page JS Plugins CSS -->
       <link rel="stylesheet" href="assets/js/plugins/slick/slick.min.css" />
       <link rel="stylesheet" href="assets/js/plugins/slick/slick-theme.min.css" />

       <!-- AppUI CSS stylesheets -->
       <link rel="stylesheet" id="css-font-awesome" href="assets/css/font-awesome.css" />
       <link rel="stylesheet" id="css-ionicons" href="assets/css/ionicons.css" />
       <link rel="stylesheet" id="css-bootstrap" href="assets/css/bootstrap.css" />
       <link rel="stylesheet" id="css-app" href="assets/css/app.css" />
       <link rel="stylesheet" id="css-app-custom" href="assets/css/app-custom.css" />
       <!-- End Stylesheets -->
   </head>

   <body class="app-ui layout-has-drawer layout-has-fixed-header">
       <div class="app-layout-canvas">
           <div class="app-layout-container">

               <!-- Drawer -->
               <aside class="app-layout-drawer">

                   <!-- Drawer scroll area -->
                   <div class="app-layout-drawer-scroll">
                       <!-- Drawer logo -->
                       <div id="logo" class="drawer-header">
                           <a href="index.html"><img class="img-responsive" src="assets/img/logo/logo-backend.png" title="AppUI" alt="AppUI" /></a>
                       </div>

                       <!-- Drawer navigation -->
                       <nav class="drawer-main">
                           <ul class="nav nav-drawer">

                               <li class="nav-item nav-drawer-header">仪表盘</li>
								
								<li class="nav-item active">
                                   <a href="admin.php"><i class="fa fa-tachometer"></i>首页</a>
                               </li>
																<li class="nav-item active">
                                   <a href="safe.php"><i class="ion-android-folder"></i>命令大全</a>
                               </li>

                               <li class="nav-item active">
                                   <a onclick="cd('service dnsmasq restart')"><i class="ion-toggle-filled"></i>立即拦截</a>
                               </li>
								<script>
function cd(line){
	if(confirm("立即拦截是更新DNS后启立即生效的作用，如果快捷命令报错请进入ssh输入reboot命令重启服务器，或者进入ssh手动执行立即拦截命令，详细请看命令大全")){
		$.post('fas_service.php',{
			 "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("执行完毕");
				location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
                           <li class="nav-item active">
                                   <a onclick="cds('jwboot')"><i class="ion-toggle-filled"></i>开启禁网</a>
                               </li>
								<script>
function cds(line){
	if(confirm("立即开启禁网吗？如果快捷命令报错请进入ssh输入reboot命令重启服务器")){
		$.post('fas_service.php',{
			 "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("开启成功");
				location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
								<li class="nav-item active">
                                   <a onclick="c('reboot')"><i class="ion-toggle"></i>关闭禁网</a>
                               </li>
<script>
function c(line){
	if(confirm("立即关闭禁网吗？如果快捷命令报错请进入ssh输入reboot命令重启服务器")){
		$.post('fas_service.php',{
			 "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("服务器重启中请耐心等待");
				location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
												
								<li class="nav-item">
                                   <a href="mysql.php"><i class="ion-ios-information"></i>数据备份</a>
                               </li>


                               <li class="nav-item nav-drawer-header">信息</li>


									<li class="nav-item nav-item-has-subnav">
                                   <a href="javascript:void(0)"><i class="fa fa-tasks"></i>DNS管理</a>
                                   <ul class="nav nav-subnav">

                                       <li>
                                           <a href="cjgf.php">刺激国服</a>
                                       </li>

                                       <li>
                                           <a href="cjgjf.php">刺激国际服</a>
                                       </li>

                                       <li>
                                           <a href="qqfc.php">QQ飞车</a>
                                       </li>

                                       <li>
                                           <a href="cfm.php">穿越火线</a>
                                       </li>

                                       <li>
                                           <a href="wzry.php">王者荣耀</a>
                                       </li>
										
										<li>
                                           <a href="hosts.php">自定义</a>
                                       </li>
										
										
  </ul>
                               </li>
                               <li class="nav-item nav-item-has-subnav">
                                   <a href="javascript:void(0)"><i class="fa fa-users"></i>用户管理</a>
                                   <ul class="nav nav-subnav">

                                       <li>
                                           <a href="user_create.php">批量生成</a>
                                       </li>

                                       <li>
                                           <a href="ur.php">上次生成用户</a>
                                       </li>

                                       <li>
                                           <a href="user_add.php">添加用户</a>
                                       </li>

                                       <li>
                                           <a href="user_list.php">用户列表<span class="badge pull-right"><?=$numrows?></span></a>
                                       </li>

                                       <li>
                                           <a href="online.php">在线用户<span class="badge pull-right"><?=$nums2?></span></a>
                                       </li>

    </ul>
                               </li>




									<li class="nav-item nav-item-has-subnav active open">
                                   <a href="javascript:void(0)"><i class="fa fa-cloud"></i>套餐管理</a>
                                   <ul class="nav nav-subnav">

                                       <li class="active">
                                           <a href="list_tc.php">套餐管理</a>
                                       </li>

                                       <li class="active">
                                           <a href="add_tc.php">新增套餐</a>
                                       </li>

                                       <li class="active">
                                           <a href="km_list.php">卡密管理</a>
                                       </li>

                                       <li class="active">
                                           <a href="sckm.php">上次生成卡密</a>
                                       </li>

                                   </ul>
                               </li>



                               <li class="nav-item nav-item-has-subnav">
                                   <a href="javascript:void(0)"><i class="fa fa-bell"></i>线路管理</a>
                                   <ul class="nav nav-subnav">

                                                                            <li>
                                           <a href="zs.php">证书管理</a>
                                       </li>

                                       <li>
                                           <a href="line_list.php">线路列表</a>
                                       </li>

                                       <li>
                                           <a href="line_add.php">添加线路</a>
                                       </li>

                                       <li>
                                           <a href="cat_add.php">分类管理</a>
                                       </li>

                                   </ul>
                               </li>




                               <li class="nav-item nav-item-has-subnav">
                                   <a href="javascript:void(0)"><i class="fa fa-magic"></i>负载管理</a>
                                   <ul class="nav nav-subnav">

                                       <li>
                                           <a href="net.php">宽带监控</a>
                                       </li>

                                       <li>
                                           <a href="note_add.php">添加节点</a>
                                       </li>

                                       <li>
                                           <a href="note_list.php">节点管理</a>
                                       </li>

                                       <li>
                                           <a href="fwq_add.php">添加服务器</a>
                                       </li>

                                       <li>
                                           <a href="fwq_list.php">服务器列表</a>
                                       </li>

                                   </ul>
                               </li>

                               <li class="nav-item nav-item-has-subnav">
                                   <a href="javascript:void(0)"><i class="fa fa-suitcase"></i>APP管理</a>
                                   <ul class="nav nav-subnav">

                                       <li>
                                           <a href="qq_admin.php">APP设置</a>
                                       </li>

                                       <li>
                                           <a href="AdminShengji.php">升级与推送</a>
                                       </li>

                                       <li>
                                           <a href="feedback.php">反馈管理</a>
                                       </li>

                                       <li>
                                           <a href="list_gg.php">公告管理</a>
                                       </li>

                                       <li>
                                           <a href="add_gg.php">发布公告</a>
                                       </li>
										
										
                                       <li>
                                           <a href="denglu.php">滚动条1</a>
                                       </li>


                                       <li>
                                           <a href="jiemian.php">滚动条2</a>
                                       </li>
                                   </ul>
                               </li>

                               <li class="nav-item nav-item-has-subnav">
                                   <a href="javascript:void(0)"><i class="fa fa-sitemap"></i>代理管理</a>
                                   <ul class="nav nav-subnav">

                                       <li>
                                           <a href="type_add.php">新增等级</a>
                                       </li>

                                       <li>
                                           <a href="type_list.php">等级列表</a>
                                       </li>

                                       <li>
                                           <a href="dl_add.php">新增代理</a>
                                       </li>
										
                                       <li>
                                           <a href="dailigg.php">代理公告</a>
                                       </li>

                                       <li>
                                           <a href="dl_list.php">代理列表</a>
                                       </li>
                                   </ul>
                               </li>

                               <li class="nav-item nav-item-has-subnav">
                                   <a href="javascript:void(0)"><i class="fa fa-cogs"></i>高级设置</a>
                                   <ul class="nav nav-subnav">

                                       <li>
                                           <a href="user.php">密码修改</a>
                                       </li>

                                       <li>
                                           <a href="float.php">限速管理</a>
                                       </li>

                                       <li>
                                           <a href="pay_user.php">收支管理</a>
                                       </li>

                                       <li>
                                           <a href="goods.php">商品管理</a>
                                       </li>
										
										<li>
                                           <a href="pay.php">参数配置</a>
                                       </li>
										

                                   </ul>
                               </li>

                           </ul>
                       </nav>
                       <!-- End drawer navigation -->

                       <div class="drawer-footer">
                           <p class="copyright">骚猪友情开发&copy;</p>
                           <a href="login.php?act=logout" target="_blank" rel="nofollow"><i class="icon-signout"></i>退出仪表</a>
                       </div>
                   </div>
                   <!-- End drawer scroll area -->
               </aside>
               <!-- End drawer -->

               <!-- Header -->
               <header class="app-layout-header">
                   <nav class="navbar navbar-default">
                       <div class="container-fluid">
                           <div class="navbar-header">

                               <button class="pull-left hidden-lg hidden-md navbar-toggle" type="button" data-toggle="layout" data-action="sidebar_toggle">
					<span class="sr-only">Toggle drawer</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
                               <span class="navbar-page-title">
					
					Dashboard
				</span>
                           </div>

                           <div class="collapse navbar-collapse" id="header-navbar-collapse">
                               <!-- Header search form -->



                               <!-- .navbar-left -->

                               <ul class="nav navbar-nav navbar-right navbar-toolbar hidden-sm hidden-xs">
                                  

                                   
                               
                                           <li>
                                               <a href="http://www.saoml.xyz">官网</a>
                                           </li>
                                           <li>
                                               <a href="https://jq.qq.com/?_wv=1027&k=5YQHBxd"><span class="badge badge-success pull-right"></span>QQ群</a>
                                           </li>
                                           <li>
                                               <a href="http://wpa.qq.com/msgrd?v=3&uin=1277345571&site=qq&menu=yes">代理</a>
                                           </li>
                                       </ul>
                                   </li>
                               </ul>
                               <!-- .navbar-right -->
                           </div>
                       </div>
                       <!-- .container-fluid -->
                   </nav>
                   <!-- .navbar-default -->
               </header>
               <!-- End header -->

               <main class="app-layout-content">

                   <!-- Page Content -->
                   <div class="container-fluid p-y-md">



       <div class="app-ui-mask-modal"></div>