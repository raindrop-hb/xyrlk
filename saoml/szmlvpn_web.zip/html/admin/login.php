<?php
//加密方式：php源码混淆类加密。免费版地址:https://www.zhaoyuanma.com/phpjm.html 免费版不能解密,可以使用VIP版本。
//此程序由【找源码】http://Www.ZhaoYuanMa.Com (免费版）在线逆向还原，QQ：7530782 
?>
<?php
$file = "../../FAS.lock";
if(file_exists($file)) 
{
	require ("error.php");
	return;
}
else 
{
	echo "";
}
?>
<?php
$display_login = true;
function getClientIP() 
{
	global $ip;
	if (getenv("HTTP_CLIENT_IP")) $ip = getenv("HTTP_CLIENT_IP");
	else if(getenv("HTTP_X_FORWARDED_FOR")) $ip = getenv("HTTP_X_FORWARDED_FOR");
	else if(getenv("REMOTE_ADDR")) $ip = getenv("REMOTE_ADDR");
	else $ip = "Unknow";
	return $ip;
}
$cip = getClientIP();
if($_GET["act"] == "do_login")
{
	require("system.php");
	$last_ip_file = R."/cache/last_ip.log";
	if(isset($_POST["user"]) && isset($_POST["pass"]))
	{
		$u = $_POST["user"];
		$p = $_POST["pass"];
		if(trim($u) == "" || trim($p) == "")
		{
			die(json_encode(["status"=>"error","msg"=>"信息不完整"]));
		}
		else
		{
			$last_ip = file_get_contents($last_ip_file);
			if($cip != $last_ip)
			{
				$auth_key = trim($_POST["auth_key"]);
				$local_key = file_get_contents("/var/www/auth_key.access");
				if($auth_key == "" || $auth_key != trim($local_key))
				{
					die(json_encode(["status"=>"error","msg"=>"口令错误"]));
				}
			}
			$admin = db("app_admin")->where(array("username"=>$u,"password"=>$p))->find();
			if($admin)
			{
				$_SESSION["dd"]["username"] = $u;
				$_SESSION["dd"]["password"] = $p;
				file_put_contents($last_ip_file,$cip);
				die(json_encode(["status"=>"success","msg"=>""]));
			}
			else
			{
				die(json_encode(["status"=>"error","msg"=>"密码错误"]));
			}
		}
	}
}
elseif($_GET["act"] == "logout")
{
	require("system.php");
	unset($_SESSION["dd"]);
	header("location:admin.php");
}
else
{
	$title="SaoML后台管理登录验证";
	include("head.php");
	$last_ip_file = R."/cache/last_ip.log";
	$last_ip = file_get_contents($last_ip_file);
	?>
<style>
.login-top{
	height:280px;
	line-height:280px;
	background:#ccc;
	background-image:url("/public/images/login_top_bg.jpg");
	color:#fff;
	font-size:60px;
	padding-top:80px;
}
.login-top img{
	display:block;
	margin:auto;
}
.login-box{
	margin-left:auto;
	margin-right:auto;
	width:450px;
}
@media screen and (max-width:768px){
	.login-top{
		height:auto;
		padding-top:0px;
	}
	.login-box{
		width:auto;
		padding:10px;
	}
}
</style>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <title>Adminity : Widget</title>


   <!-- Styles -->
	<link rel="stylesheet" id="css-font-awesome" href="assets/css/font-awesome.css" />
   <link rel="stylesheet" id="css-ionicons" href="assets/css/ionicons.css" />
   <link rel="stylesheet" id="css-bootstrap" href="assets/css/bootstrap.css" />
   <link rel="stylesheet" id="css-app" href="assets/css/app.css" />
   <link rel="stylesheet" id="css-app-custom" href="assets/css/app-custom.css" />
   <link href="assets/css/lib/font-awesome.min.css" rel="stylesheet">
   <link href="assets/css/lib/themify-icons.css" rel="stylesheet">
   <link href="assets/css/lib/bootstrap.min.css" rel="stylesheet">
   <link href="assets/css/lib/unix.css" rel="stylesheet">
   <link href="assets/css/lib/style.css" rel="stylesheet">
</head>

<body class="bg-primary">

   <div class="unix-login">
       <div class="container">
           <div class="row">
               <div class="col-lg-6 col-lg-offset-3">
                   <div class="login-content">
                       <div class="login-logo">
                           <a href="index.html"><span>SaoMLdmin</span></a>
                       </div>
                       <div class="login-form">
                           <h4>Administratior Login</h4>
                               <div class="form-group">
                                   <label>管理员账号</label>
									<input type="text" placeholder="user" class="form-control" name="user">
                               </div>
                               <div class="form-group">
                                   <label>管理员密码</label>
									<input type="password" id="inputPassword" placeholder="password" class="form-control" name="pass">
                               </div>
								<?php if($cip != $last_ip)
	{
		?>
                               <div class="form-group">
                                   <label>安全码</label>
									<input type="password" id="inputPassword" placeholder="KEY" class="form-control" name="auth_key">
                               </div>
		<?php }
	?>
                               <div class="checkbox">
                                   <label>
										<input type="checkbox">记住密码
									</label>
                                <!--   <label class="pull-right">
										<a href="#">忘记安全码?</a> -->
									</label>
                               </div>
								<button type="submit" class="btn btn-primary btn-flat m-b-30 m-t-30 do_login">登录</button>
								<button class="js-notify btn btn-sm btn-info" data-notify-type="info" data-notify-align="center" data-notify-message="执行命令：cat /var/www/auth_key.access">忘记安全码？</button>
                               <div class="social-login-content">
                                   <div class="social-button">
                                        <a href="http://www.saoml.xyz" type="button" class="btn btn-primary bg-facebook btn-flat btn-addon m-b-10">SaoML：官网</a>
                                        <a href="https://jq.qq.com/?_wv=1027&k=5YQHBxd" type="button" class="btn btn-primary bg-twitter btn-flat btn-addon m-t-10">SaoML：Q群</a>
										<a href="http://wpa.qq.com/msgrd?v=3&uin=1277345571&site=qq&menu=yes" type="button" class="btn btn-primary bg-twitter btn-flat btn-addon m-t-10">SaoML：QQ</a>
                                   </div>
                               </div>
                               <div class="register-link m-t-15 text-center">
                                   <p>你是不是管理员?<a href="#">不是管理员麻烦自觉关闭</a></p>
                               </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </div>
	<script>
	$(function(){
		$(".do_login").click(function(){
			var username = $("[name='user']").val();
			var password = $("[name='pass']").val();
			var auth_key = $("[name='auth_key']").val();
			if(username == "" || password == ""){
				alert("信息不完整");
			}else{
				$.post("?act=do_login",
				{
					"user":username,
					"pass":password,
					"auth_key":auth_key
				},function(data){
					if(data.status == "success"){
						window.location.href="admin.php";
					}else{
						alert(data.msg);
					}
				},"JSON");
			}
		});
	});
	</script>
       
		<div class="app-ui-mask-modal"></div>

       <!-- AppUI Core JS: jQuery, Bootstrap, slimScroll, scrollLock and App.js -->
       <script src="assets/js/core/jquery.min.js"></script>
       <script src="assets/js/core/bootstrap.min.js"></script>
       <script src="assets/js/core/jquery.slimscroll.min.js"></script>
       <script src="assets/js/core/jquery.scrollLock.min.js"></script>
       <script src="assets/js/core/jquery.placeholder.min.js"></script>
       <script src="assets/js/app.js"></script>
       <script src="assets/js/app-custom.js"></script>

       <!-- Page JS Plugins -->
       <script src="assets/js/plugins/bootstrap-notify/bootstrap-notify.min.js"></script>

       <!-- Page JS Code -->
       <script>
           $(function()
           {
               // Init page helpers (BS Notify Plugin)
               App.initHelpers('notify');
           });
       </script>
</body>

</html>
<?php  include("footer.php");
}
?>