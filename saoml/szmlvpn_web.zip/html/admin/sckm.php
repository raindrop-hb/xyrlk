<?php
include("head.php");
include("tc.php");
echo '<div class="box">';
if(is_file("kmdata.php")){
	include("kmdata.php");
	$time = filemtime("kmdata.php");
	$count = count($km);
	echo "<h3>记录时间 ".date("Y/m/d H:i:s",$time)." 共".$count."条</h3><hr>";
	foreach($km as $vo){
		echo $vo."<br>";
	}
	echo "<hr>";
}else{
	echo "您还没有生成记录哦";
}
echo "</div>";
include("footer.php");
 ?>
        <script src="assets/js/core/jquery.min.js"></script>
        <script src="assets/js/core/bootstrap.min.js"></script>
        <script src="assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="assets/js/core/jquery.placeholder.min.js"></script>
        <script src="assets/js/app.js"></script>
        <script src="assets/js/app-custom.js"></script>

        <!-- Page Plugins -->
        <script src="assets/js/plugins/slick/slick.min.js"></script>
        <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

        <!-- Page JS Code -->
        <script src="assets/js/pages/index.js"></script>
        <script>
            $(function()
            {
                // Init page helpers (Slick Slider plugin)
                App.initHelpers('slick');
            });
        </script>