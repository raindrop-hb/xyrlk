<?php
echo 'Found Notฃก';
?>