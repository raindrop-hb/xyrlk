<?php
//加密方式：php源码混淆类加密。免费版地址:https://www.zhaoyuanma.com/phpjm.html 免费版不能解密,可以使用VIP版本。
//此程序由【找源码】http://Www.ZhaoYuanMa.Com (免费版）在线逆向还原，QQ：7530782 
?>
<?php
require('head.php');
require('dns.php');
function unsetLine($arr)
{
	foreach($arr as $v)
	{
		if(strpos($v,"apache") === 0)
		{
		}
		else
		{
			$line[] = $v;
		}
	}
	return $line;
}
$m = new Map();
if($_GET['act'] == 'update')
{
	$info = file_put_contents("/etc/cjgjf",$_POST["content"]);
	tip_success("导入成功,记得立即拦截才能生效",$_SERVER['HTTP_REFERER']);
}
else
{
	$url='https://pigvpn-1251861453.cos-website.ap-chengdu.myqcloud.com/cjgjf.txt';
	$action = "?act=update";
	$info = file_get_contents("$url");
	echo$html;
	?>

<div class="main">
	<div class="box">
		<form class="form-horizontal" role="form" method="POST" action="<?php echo $action?>">

	<span class="label label-default">刺激国际服</span>
		<h3>刺激国际服DNS推送列表</h3>
		请等页面加载完毕再操作，否则卡死你个瓜娃子，导入后点立即拦截，更新dns请清除原数据
		<hr>
				<button type="submit" class="btn btn-app-red">一键导入</button>	
				<button onclick="DNS('dns.sh cjgjf')" type="button" class="btn btn-app-green">清除数据</button>	
<script>
function DNS(line){
	if(confirm("确定清除吗？")){
		$.post('fas_service.php',{
			 "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("清除成功，如报错请进入ssh执行reboot命令");
				location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
			<hr>
			
			<textarea class="form-control" rows="20" name="content"><?php echo $info ?></textarea>
			<br>
	
	</form> 
	</div>
</div>
<script src="assets/js/core/jquery.min.js"></script>
       <script src="assets/js/core/bootstrap.min.js"></script>
       <script src="assets/js/core/jquery.slimscroll.min.js"></script>
       <script src="assets/js/core/jquery.scrollLock.min.js"></script>
       <script src="assets/js/core/jquery.placeholder.min.js"></script>
       <script src="assets/js/app.js"></script>
       <script src="assets/js/app-custom.js"></script>

       <!-- Page Plugins -->
       <script src="assets/js/plugins/slick/slick.min.js"></script>
       <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

       <!-- Page JS Code -->
       <script src="assets/js/pages/index.js"></script>
       <script>
           $(function()
           {
               // Init page helpers (Slick Slider plugin)
               App.initHelpers('slick');
           });
       </script>
<?php
}
include('footer.php');
?>