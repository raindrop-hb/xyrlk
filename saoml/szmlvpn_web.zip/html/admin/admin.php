<?php
//加密方式：php源码混淆类加密。免费版地址:https://www.zhaoyuanma.com/phpjm.html 免费版不能解密,可以使用VIP版本。
//此程序由【找源码】http://Www.ZhaoYuanMa.Com (免费版）在线逆向还原，QQ：7530782 
?>
<?php
$file = "../../FAS.lock";
if(file_exists($file)) 
{
	require ("error.php");
	return;
}
else 
{
	echo "";
}
?>
<?php
require('head.php');
require('nav.php');
function unsetLine($arr)
{
	foreach($arr as $v)
	{
		if(strpos($v,"apache") === 0)
		{
		}
		else
		{
			$line[] = $v;
		}
	}
	return $line;
}
$nums = db(_openvpn_)->getnums();
$user_num = db(_openvpn_)->where(["i"=>"1"])->getnums();
$nums2 = db(_openvpn_)->where(["online"=>"1"])->getnums();
$nums3 = db("auth_fwq")->where()->getnums();
$key = file_get_contents("license.key");
?>
<style>
#line
{
	width: 100%;
	height: 385px;
	
}
#pie
{
	width: 100%;
	height: 400px;
	
}
.box-group{
	color:#222;
	font-size:16px;
	text-align:center;
	border-bottom:4px solid #328cc9;
	padding:10px 0px;
	margin:0px 10px;
}
.i-box{
	margin-bottom:15px;
	background:#fff;
	height:85px;
	position:relative;
	padding:15px;
}

.i-box .i-icon{
	position:absolute;
	width:55px;
	height:55px;
	line-height:55px;
	text-align:center;
	font-size:25px;
	background:#4bb0e5;
	color:#fff;
	border-radius:30px;
}
.i-box .i-right{
	padding-top:3px;
	margin-left:75px;
	height:60px;
}
</style>


                       <div class="row">
                           <div class="col-sm-6 col-lg-3">
                               <a class="card" href="javascript:void(0)">
                                   <div class="card-block clearfix">
                                       <div class="pull-right">
                                           <p class="h6 text-muted m-t-0 m-b-xs">注册用户</p>
                                           <p class="h3 text-blue m-t-sm m-b-0"><?=$nums?> 人</p>
                                       </div>
                                       <div class="pull-left m-r">
                                           <span class="img-avatar img-avatar-48 bg-blue bg-inverse"><i class="ion-ios-bell fa-1-5x"></i></span>
                                       </div>
                                   </div>
                               </a>
                           </div>
                           <!-- .col-sm-6 -->

                           <div class="col-sm-6 col-lg-3">
                               <a class="card bg-green bg-inverse" href="javascript:void(0)">
                                   <div class="card-block clearfix">
                                       <div class="pull-right">
                                           <p class="h6 text-muted m-t-0 m-b-xs">在线人数</p>
                                           <p class="h3 m-t-sm m-b-0"><?=$nums2?> 人</p>
                                       </div>
                                       <div class="pull-left m-r">
                                           <span class="img-avatar img-avatar-48 bg-gray-light-o"><i class="ion-ios-people fa-1-5x"></i></span>
                                       </div>
                                   </div>
                               </a>
                           </div>
                           <!-- .col-sm-6 -->

                           <div class="col-sm-6 col-lg-3">
                               <a class="card bg-blue bg-inverse" href="javascript:void(0)">
                                   <div class="card-block clearfix">
                                       <div class="pull-right">
                                           <p class="h6 text-muted m-t-0 m-b-xs">服务器数</p>
                                           <p class="h3 m-t-sm m-b-0"><?=$nums3?> 台</p>
                                       </div>
                                       <div class="pull-left m-r">
                                           <span class="img-avatar img-avatar-48 bg-gray-light-o"><i class="ion-ios-speedometer fa-1-5x"></i></span>
                                       </div>
                                   </div>
                               </a>
                           </div>
                           <!-- .col-sm-6 -->

                           <div class="col-sm-6 col-lg-3">
                               <a class="card bg-purple bg-inverse" href="javascript:void(0)">
                                   <div class="card-block clearfix">
                                       <div class="pull-right">
                                           <p class="h6 text-muted m-t-0 m-b-xs"><?=date("Y/m/d H:i")?></p>
                                           <p class="h3 m-t-sm m-b-0">系统时间</p>
                                       </div>
                                       <div class="pull-left m-r">
                                           <span class="img-avatar img-avatar-48 bg-gray-light-o"><i class="ion-ios-email fa-1-5x"></i></span>
                                       </div>
                                   </div>
                               </a>
                           </div>
							                      

<?php
exec("top -bn1 | grep Cpu",$cpuinfo);
preg_match('/\s*([0-9\.]*)\s*id/is',$cpuinfo[0],$cpuinfo_free);
$lyl = 100-(float)$cpuinfo_free[1];
?>
		 
                           <div class="col-sm-6 col-lg-3">
                               <div class="card">
                                   <div class="card-header bg-purple bg-inverse">
                                       <h2><span class="bwjk">Loading</span>&nbsp;Mbps/s</h2>
                                       <ul class="card-actions">
                                           <li>
                                               <button type="button"><i class="ion-more"></i></button>
                                           </li>
                                       </ul>
                                   </div>
                                   <div class="card-block">
                                       <p>网速监控</p>
                                   </div>
                               </div>
                           </div>
                           <!-- .col-sm-6 -->

                           <div class="col-sm-6 col-lg-3">
                               <div class="card">
                                   <div class="card-header bg-cyan bg-inverse">
                                       <h2><span class=""><?=$lyl?></span>&nbsp;%</h2>
                                       <ul class="card-actions">
                                           <li>
                                               <button type="button"><i class="ion-more"></i></button>
                                           </li>
                                       </ul>
                                   </div>
                                   <div class="card-block">
                                       <p>系统运行</p>
                                   </div>
                               </div>
                           </div>
                           <!-- .col-sm-6 -->


<?php
exec(" ps aux|grep jk.sh",$jiankong);
$jiankong = unsetLine($jiankong);
$run = false;
foreach($jiankong as $v)
{
	$run = true;
}
if($run)
{
	echo '<div class="col-sm-6 col-lg-3">';
	echo '<div class="card">';
	echo '<div class="card-header bg-teal bg-inverse">';
	echo '<h2>运行正常</h2>';
	echo '<ul class="card-actions">';
	echo '<li>';
	echo '<button type="button"><i class="ion-more"></i></button>';
	echo '</li>';
	echo '</ul>';
	echo '</div>';
	echo '<div class="card-block">';
	echo '<p>用户状态扫描</p>';
	echo '</div>';
	echo '</div>';
	echo '</div>';
}
else
{
	echo '<div class="col-sm-6 col-lg-3">';
	echo '<div class="card">';
	echo '<div class="card-header bg-teal bg-inverse">';
	echo '<h2>运行异常</h2>';
	echo '<ul class="card-actions">';
	echo '<li>';
	echo '<button type="button"><i class="ion-more"></i></button>';
	echo '</li>';
	echo '</ul>';
	echo '</div>';
	echo '<div class="card-block">';
	echo '<p>用户状态扫描</p>';
	echo '</div>';
	echo '</div>';
	echo '</div>';
}
?>

 <div class="col-sm-6 col-lg-3">
 <div class="card">
 <div class="card-header bg-light bg-inverse">
		<?php
exec(" ps aux|grep FasAUTH.bin",$jiankong2);
$jiankong2 = unsetLine($jiankong2);
$run = false;
foreach($jiankong2 as $v)
{
	$run = true;
}
if($run)
{
	echo '<h2>运行异常</h2>';
	echo '<ul class="card-actions">';
	echo '<li>';
	echo '<button type="button"><i class="ion-more"></i></button>';
	echo '</li>';
	echo '</ul>';
	echo '</div>';
	echo '<div class="card-block">';
	echo '<p>用户流量监控</p>';
}
else
{
	echo '<h2>运行正常</h2>';
	echo '<ul class="card-actions">';
	echo '<li>';
	echo '<button type="button"><i class="ion-more"></i></button>';
	echo '</li>';
	echo '</ul>';
	echo '</div>';
	echo '<div class="card-block">';
	echo '<p>用户流量监控</p>';
}
?>
    </div>
                               </div>
                           </div>

	<div class="col-xs-12 col-sm-9">
		<div class="box" style="margin-bottom:15px;">
			<div id="line"> 加载中... </div>
			<div class="box-z"></div>
		</div>
		
		<div class="box" style="margin-bottom:15px">
			<div class="row"><div class="col-xs-12 col-sm-6"> 
				<h3>TCP端口监听</h3>
				<h6><b>*</b>您的系统目前以对如下TCP端口进行了监听</h6>
				<?php
exec(" netstat -nap|grep tcp|grep \"0.0.0.0:\"",$tcp);
$tcp = unsetLine($tcp);
preg_match_all("/\:([0-9]*)/",implode("\n",$tcp),$m);
foreach($m[1] as $v)
{
	echo '<span class="label label-info">'.$v.'</span> ';
}
?>
				</div>
				<div class="col-xs-12 col-sm-6"> 
						<h3>UDP端口监听</h3>
						 <h6><b>*</b>您的系统目前以对如下UDP端口进行了监听</h6>
						<?php
exec(" netstat -nap|grep udp|grep \"0.0.0.0:\"",$udp);
$udp = unsetLine($udp);
preg_match_all("/\:([0-9]*)/",implode("\n",$udp),$m);
foreach($m[1] as $v)
{
	echo '<span class="label label-info">'.$v.'</span> ';
}
?>
				</div>
			</div>
		</div>
	</div>

	               <div class="col-xs-12 col-sm-3"> 
                               <div class="card">
								
								
								
								
		<?php
function array_space_del($arr)
{
	foreach($arr as $key=>$vo)
	{
		if(trim($vo) != "")
		{
			$b[] = $vo;
		}
	}
	return $b;
}
exec("ifconfig",$net);
foreach($net as $line)
{
	if(trim($line)=="")
	{
		$nets[] = $netinfo;
		$netinfo = array();
	}
	else
	{
		$netinfo[] = $line;
	}
}
foreach($nets as $info)
{
	$t = explode(":",$info[0]);
	$netname = $t[0];
	foreach($info as $v)
	{
		$t2 = explode(" ",$v);
		$t2 = array_space_del($t2);
		switch($t2[0])
		{
			case $netname.":": $net_mtu = $t2[3];
			break;
			case "inet": $net_ip = $t2[1];
			break;
			case "RX": if($t2[1] == "packets")
			{
				$net_recv = $t2[4];
			}
			break;
			case "TX": if($t2[1] == "packets")
			{
				$net_sent = $t2[4];
			}
			break;
		}
	}
	$arr3 = printmb($net_mtu);
	$arr1 = printmb($net_recv);
	$arr2 = printmb($net_sent);
	echo '<div class="card-header">';
	echo '<h4>IP:'.$net_ip.'</h4>';
	echo '</div>';
	echo '<div class="card-block text-center">';
	echo '<div class="row">';
	echo '<div class="col-xs-6 b-r">';
	echo '<p class="h4 m-y-0">下行</p>';
	echo '<small class="text-muted">'.round($arr1['n'],1).$arr1['p'].'</small>';
	echo '</div>';
	echo '<div class="col-xs-6">';
	echo '<p class="h4 m-y-0">上行</p>';
	echo '<small class="text-muted">'.round($arr2['n'],1).$arr2['p'].'</small>';
	echo '</div>';
	echo '</div>';
	echo '</div>';
}
?>
                              



							  </div>

                           </div>
                         
	
	
                         
     <script type="text/javascript">
  
	AmCharts.ready(function () {
		$.post("rateJson.php?",{},function(json){
			var chart = new AmCharts.AmSerialChart();
			chart.dataProvider = json;
			chart.categoryField = "name";
			chart.angle = 30;
			chart.depth3D = 20;
			//标题
			chart.addTitle("15天流量趋势(单位GB)", 15);  
			var graph = new AmCharts.AmGraph();
			chart.addGraph(graph);
			graph.valueField = "value";
			//背景颜色透明度
			graph.fillAlphas = 0.3;
			//类型
			graph.type = "line";
			//圆角
			graph.bullet = "round";
			//线颜色
			graph.lineColor = "#328cc9";
			//提示信息
			graph.balloonText = "[[value]] G";
			var categoryAxis = chart.categoryAxis;
			categoryAxis.autoGridCount = false;
			categoryAxis.gridCount = json.length;
			categoryAxis.gridPosition = "start";
			chart.write("line");
		},"JSON");
       
   });
   $(function(){
		$.post("rateJson.php?act=bwi",{},function(data){
				$(".bwjk").html(data);
			});
		setTimeout(function(){
			$.post("rateJson.php?act=bwi",{},function(data){
				$(".bwjk").html(data);
			});
		}, 10000);
		
	});
</script>
<script src="assets/js/core/jquery.min.js"></script>
       <script src="assets/js/core/bootstrap.min.js"></script>
       <script src="assets/js/core/jquery.slimscroll.min.js"></script>
       <script src="assets/js/core/jquery.scrollLock.min.js"></script>
       <script src="assets/js/core/jquery.placeholder.min.js"></script>
       <script src="assets/js/app.js"></script>
       <script src="assets/js/app-custom.js"></script>

       <!-- Page Plugins -->
       <script src="assets/js/plugins/slick/slick.min.js"></script>
       <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
       <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

       <!-- Page JS Code -->
       <script src="assets/js/pages/index.js"></script>
       <script>
           $(function()
           {
               // Init page helpers (Slick Slider plugin)
               App.initHelpers('slick');
           });
       </script>
<?php
include("footer.php");
?>