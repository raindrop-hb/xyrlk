#!/bin/bash
type=$1
port=$2
	/root/res/proxy.bin -l $port -d
	read has < <(cat /etc/sysconfig/iptables | grep "tcp \-\-dport $port \-j ACCEPT" )
	if [ -z "$has" ];then
		iptables -A INPUT -p tcp -m tcp --dport $port -j ACCEPT
		service iptables save
	fi
	read has2 < <(cat /root/res/portlist.conf | grep "port $port tcp" )
	if [ -z "$has2" ];then
		echo -e "port $port tcp">>/root/res/portlist.conf
	fi
	read has < <(cat /etc/sysconfig/iptables | grep "udp \-\-dport $port \-j ACCEPT" )
	if [ -z "$has" ];then
		iptables -A INPUT -p udp -m udp --dport $port -j ACCEPT
		service iptables save
	fi
	iptables -t nat -A PREROUTING -p udp --dport $port -j REDIRECT --to-ports 53 && service iptables save