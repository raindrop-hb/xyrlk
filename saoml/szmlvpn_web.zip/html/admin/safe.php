<?php
	include('head.php');
	include('nav.php');
	$m = new Map();
 	if($_GET['act'] == 'del'){
		$port = file_get_contents("/root/res/portlist.conf");
		$p = '/port\s*([0-9]*)\s*tcp/';
		preg_match_all($p,$port,$m);
		echo '<span class="label label-default">代理端口</span>';
		foreach($m[1] as $vo){
			if($vo!=$_GET["port"]){
				$line[] = "port $vo tcp";
			}
		}
		$content = implode("\n",$line);
		file_put_contents("/root/res/portlist.conf",$content);
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
	}elseif($_GET['act'] == 'update'){
		
 		$limit = $_POST["limit"];
 		$content = "default {$limit}
		total 1000";
		$info = file_put_contents("/etc/openvpn/bwlimitplugin.cnf",$content);
 		
		tip_success("修改成功",$_SERVER['HTTP_REFERER']);
		
	}else{
		$action = "?act=update";
		
		$info = file_get_contents("/etc/openvpn/bwlimitplugin.cnf");
		$p = '/default\s([0-9]*)/';
		preg_match($p,$info,$m);
		
 ?>
<div class="main">
	<div class="box">
	<span class="label label-default">高级管理</span>
		<h3>代理端口列表</h3>
		<?php
			$port = file_get_contents("/root/res/portlist.conf");
			$p = '/port\s*([0-9]*)\s*tcp/';
			preg_match_all($p,$port,$m);
			echo '<span class="label label-default">udp+tcp端口</span>';
			foreach($m[1] as $vo){
				echo $vo.'[<a href="?act=del&port='.$vo.'" onclick="if(confirm(\'删除后重启VPN生效\')){return true;}else{return false;}">删除</a>]&nbsp;';
			}
		?>
	<hr>

<!-- 模态框（Modal） -->
			<div class="modal-header">
				<h4 class="modal-title" id="myModalLabel">
					添加udp+tcp端口
				</h4>
			</div>
			<div class="modal-body">
				 <div class="form-group">
					<label for="name">请您注意</label>
					再开启端口前，请查看服务器安全组是否放行端口
					此功能会默认开启udp和tcp端口，比如你要开启666端口，那么udp666和tcp666端口都会自动开启，请不要重复</div>
				  <div class="form-group">
					<label for="name">请输入端口</label>
				<input type="text" class="form-control" id="port" placeholder=""  value="666">
					
				  </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-app-green save">
					提交更改
				</button>
			</div>
			
			
			<!-- 模态框（Modal） -->
			<div class="modal-header">
				<h4 class="modal-title" id="myModalLabel">
					修改WEB端口
				</h4>
			</div>
			<div class="modal-body">
				
				 <div class="form-group">
					<label for="name">请您注意</label>
					请保证端口没有被占用，否则，流控可能无法启动</div>
				  <div class="form-group">
					<label for="name">请输入端口</label>
				<input type="text" class="form-control" id="webport" placeholder=""  value="80">
				  </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-app-green save2">
					提交更改
				</button>
			</div>
			<div class="modal-header">
				<h4 class="modal-title" id="myModalLabel">
					手动命令列表
				</h4>
			</div>
						<div class="modal-body">
				
	    <div class="form-group">
		以下命令都需要进入ssh终端界面执行,执行不会返回结果，只要执行了就生效</div>
		<span class="label label-default">重启VPN：vpn restart</span>
		<span class="label label-default">重启数据库：systemctl restart httpd.service</span>
		<span class="label label-default">重启Apache：systemctl restart iptables.service </span>
		<span class="label label-default">DNS立即生效：systemctl restart dnsmasq.service</span>
		<span class="label label-default">开端口：port</span>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->	



























<script>
$(function(){   
	   $(".save").click(function(){
		   var nums = $("#port").val();
		   if(nums == ""){
			   alert("请输入端口号");
		   } 
		   $.post('fas_service.php',{
			   "cmd":'/var/www/html/admin/lib/addport.sh tcp '+nums
			  
			},function(data){
				if(data.status == "success"){
					alert("执行完毕。请在后台首页查看是否已经添加成功");
					location.reload();
				}else{
					alert(data.msg);
				}
			},"JSON");
	   });
	   
	   $(".save2").click(function(){
		   var nums = $("#webport").val();
		   if(nums == ""){
			   alert("请输入端口号");
		   } 
		   $.post('fas_service.php',{
			   "cmd":'/var/www/html/admin/lib/modWebPort.sh '+nums
			  
			},function(data){
				if(data.status == "success"){
					alert("执行完毕。请尝试以新端口访问流控。");
					<?php
						$HOST = explode(":",$_SERVER["HTTP_HOST"]);
						$domain = $HOST[0];
						$port = $HOST[1];
					?>
					location.href="http://<?= $domain?>:"+nums+"/admin/";
				}else{
					alert(data.msg);
				}
			},"JSON");
	   });
	});
function cmds(line){
	if(confirm("确认执行此命令？部分命令执行后可能没有结果反馈")){
		$.post('fas_service.php',{
			  "cmd":line  
		},function(data){
			if(data.status == "success"){
				alert("执行完毕");
				//location.reload();
			}else{
				alert(data.msg);
					}
		},"JSON");
	}
	
}
</script>
<script src="assets/js/core/jquery.min.js"></script>
        <script src="assets/js/core/bootstrap.min.js"></script>
        <script src="assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="assets/js/core/jquery.placeholder.min.js"></script>
        <script src="assets/js/app.js"></script>
        <script src="assets/js/app-custom.js"></script>

        <!-- Page Plugins -->
        <script src="assets/js/plugins/slick/slick.min.js"></script>
        <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

        <!-- Page JS Code -->
        <script src="assets/js/pages/index.js"></script>
        <script>
            $(function()
            {
                // Init page helpers (Slick Slider plugin)
                App.initHelpers('slick');
            });
        </script>
<?php
	}
	include('footer.php');
?>
