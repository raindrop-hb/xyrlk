<?php

include('head.php');
include('nav.php');

	if($_GET["act"] == "mod"){
		$db = db('app_daili');
		if($db->where(['id'=>$admin['id']])->update(['content'=>$_POST['content']])){
			tip_success("公告修改成功",$_SERVER['HTTP_REFERER']);
		}else{
			tip_failed("十分抱歉修改失败",$_SERVER['HTTP_REFERER']);
		}
	}else{
		
 ?>
   
<div class="box">
   
 <form role="form" action="?act=mod" method="POST">
  <div class="form-group">
    <label for="name">客服页面的文字内容 支持HTML</label>
    <textarea class="form-control" rows="6" name="content"><?=$admin["content"]?></textarea>
  </div>
  <input type="submit" class="btn btn-default mod" value="确认修改">
  </form>
</div>
<script src="assets/js/core/jquery.min.js"></script>
        <script src="assets/js/core/bootstrap.min.js"></script>
        <script src="assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="assets/js/core/jquery.placeholder.min.js"></script>
        <script src="assets/js/app.js"></script>
        <script src="assets/js/app-custom.js"></script>

        <!-- Page Plugins -->
        <script src="assets/js/plugins/slick/slick.min.js"></script>
        <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

        <!-- Page JS Code -->
        <script src="assets/js/pages/index.js"></script>
        <script>
            $(function()
            {
                // Init page helpers (Slick Slider plugin)
                App.initHelpers('slick');
            });
        </script>
<?php include('footer.php'); };?>