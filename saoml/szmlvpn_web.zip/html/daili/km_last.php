<?php
include("head.php");
include("nav.php");
echo '<div class="box">';
$km = db("app_kms");
$order = $km->where(["daili"=>$admin["id"]])->order("id DESC")->find();
if($order){
	$list = $km->where(["daili"=>$admin["id"],"addtime"=>$order["addtime"]])->order("id DESC")->select();
	echo "<h3>生成时间：".date("Y/m/d H:i:s",$order["addtime"])."</h3><br>";
	foreach($list as $vo){
		echo $vo["km"]."<br>";
	}
}
echo "</div>";
include("../footer.php");
?>
<script src="assets/js/core/jquery.min.js"></script>
        <script src="assets/js/core/bootstrap.min.js"></script>
        <script src="assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="assets/js/core/jquery.placeholder.min.js"></script>
        <script src="assets/js/app.js"></script>
        <script src="assets/js/app-custom.js"></script>

        <!-- Page Plugins -->
        <script src="assets/js/plugins/slick/slick.min.js"></script>
        <script src="assets/js/plugins/chartjs/Chart.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.pie.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.stack.min.js"></script>
        <script src="assets/js/plugins/flot/jquery.flot.resize.min.js"></script>

        <!-- Page JS Code -->
        <script src="assets/js/pages/index.js"></script>
        <script>
            $(function()
            {
                // Init page helpers (Slick Slider plugin)
                App.initHelpers('slick');
            });
        </script>