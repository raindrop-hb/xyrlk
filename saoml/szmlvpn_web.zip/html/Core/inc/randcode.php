<?php
require('../../system.php');
//生成验证码图片

?>